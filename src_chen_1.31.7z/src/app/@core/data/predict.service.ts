import { Injectable } from '@angular/core';

@Injectable()
export class PredictService {
   private data= [{
    'date': '2013-01-16',
    'usage': 71,
    'ib': 75,
  }, {
    'date': '2014-01-17',
    'usage': 74,
    'ib': 78,
  }, {
    'date': '2015-01-18',
    'usage': 78,
    'ib': 88,
  }, {
    'date': '2016-01-19',
    'RA': 75,
    'RA-Shift': 89,
    'usage': 89,
    'ib': 75,
    'IB': 80,
    'Factual': 90,
  }, {
    'date': '2017-01-20',
    'RA': 72,
    'RA-Shift': 89,
    'IB': 90,
    'Factual': 60,
  }, {
    'date': '2018-01-21',
    'RA': 73,
    'RA-Shift': 85,
    'IB': 30,
    'Factual': 50,
  }, {
    'date': '2019-01-22',
    'RA': 78,
    'RA-Shift': 92,
    'IB': 50,
    'Factual': 70,
  }, {
    'date': '2020-01-23',
    'RA': 75,
    'RA-Shift': 90,
    'IB': 70,
    'Factual': 60,
  }, {
    'date': '2021-01-24',
    'RA': 75,
    'RA-Shift': 91,
    'IB': 90,
    'Factual': 50,
  }, {
    'date': '2022-01-25',
    'RA': 70,
    'RA-Shift': 84,
    'IB': 50,
    'Factual': 80,
  }, {
    'date': '2023-01-26',
    'RA': 77,
    'RA-Shift': 92,
    'IB': 40,
    'Factual': 80,
  }, {
    'date': '2024-01-27',
    'RA': 74,
    'RA-Shift': 87,
    'IB': 62,
    'Factual': 85,
  }, {
    'date': '2025-01-28',
    'RA': 73,
    'RA-Shift': 88,
    'IB': 75,
    'Factual': 87,
  }, {
    'date': '2026-01-29',
    'RA': 74,
    'RA-Shift': 87,
    'IB': 50,
    'Factual': 80,
  }, {
    'date': '2027-01-30',
    'RA': 72,
    'RA-Shift': 85,
    'IB': 40,
    'Factual': 70,
  },
   {
    'date': '2028-01-30',
    'RA': 63,
    'RA-Shift': 86,
    'IB': 60,
    'Factual': 85,
  },
  {
    'date': '2029-01-30',
  }];
  constructor() { }
  getData() {
    return this.data;
  }
}
