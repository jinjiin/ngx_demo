import { Component} from '@angular/core';
@Component({
  selector: 'ngx-pagetocrawl',
  template: '<div></div>',
})
export class PageToCrawlComponent {
  Url: string;
  constructor () {}

}
